<div class="breadcrumb-area text-center shadow dark text-light bg-cover" style="background-image: url(<?= base_url('assets/web/') ?>img/banner/13.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1>Careers</h1>
                    <ul class="breadcrumb">
                        <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
                        <li class="active">Careers</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
  


    <div class="earna-career default-padding bg-gray">
        <div class="right-shape">
            <img src="<?= base_url('assets/web/') ?>img/shape/9.png" alt="Shape">
        </div>
        <div class="container">
         
            <div class="job-lists">
                <div class="row">
                    <?php
                    if($careers) {
                        foreach($careers as $career) {
                            ?>
                            <div class="col-lg-6" style="margin-bottom: 30px;">
                            <!-- Single Item -->
                            <div class="item" style="min-height: 200px;">
                                <div class="info">
                                    <h4>
                                        <a href="<?= $career->link ?>" target="_blank"><?= $career->title ?></a>
                                    </h4>
                                    <ul>
                                        <li>Job Location : <?= $career->location ?></li>
                                        <?php
                                        if($career->subtitle != '') {
                                            ?>
                                            <li>Job Description : <a href="<?= base_url()?>career/view/<?= $career->id ?>">Full Details</a></li>
                                            <?php
                                        }
                                        ?>
                                        <li>Status : <span style="color: #00cf10; font-weight: 600;"><?= ($career->status == 'P') ? 'Open' : 'Closed'; ?></span></li>
                                        <li>Posting Date : <?= date('d-m-Y',$career->published_at) ?></li>
                                    </ul>
                                </div>
                                <div class="button">
                                    <a class="btn btn-gradient effect btn-md" href="<?= base_url()?>contact_us/post/<?= $career->id ?>">APPLY</a>
                                </div>
                            </div>
                            <!-- End Single Item -->
                            </div>
                            <?php
                        }
                    }
                    ?>
                </div>
            </div>

        </div>
    </div>


    


    
    <!-- ("overflow-hidden-box overflow-hidden" helps you to ignore extra width for the circle shape)-->
    <div class="overflow-hidden-box overflow-hidden">
 

        <!-- Star testimonials Area
        ============================================= -->
        <div class="testimonials-area bg-gray default-padding-bottom">
            <!-- Fixed Shape -->
            <div class="fixed-shape" style="background-image: url(<?= base_url('assets/web/') ?>img/shape/10-red.png);"></div>
            <!-- End Fixed Shape -->
            <div class="container">
                <div class="testimonial-items">
                    <div class="row align-center">
                        <div class="col-lg-7 testimonials-content">
                            <div class="testimonials-carousel owl-carousel owl-theme">
                                 <!-- Single Item -->
                                <div class="item">
                                    <div class="info">
                                        <p>
                                            
                                           Soaring High for Excellence! <br>
The Team is very accommodating. They treat their client's, me with respect and very professionally-driven responses.
A big thanks to Mr Tamer, Sir for the shared opportunity.<br>
I got my interview today, though it was very short yet I was able to express myself. Hoping to pass the interview and soon work with. 
Continue inspiring people. 
                                            
                                            </p>
                                        <div class="provider">
                                           
                                            <div class="content">
                                                <h4>Mhyr Orbita</h4>
                                                <span>  </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Item -->
                                <!-- Single Item -->
                                <div class="item">
                                    <div class="info">
                                        <p>
                                             An excellent experience with an excellent arrangement interview online, Keep up the Good Work! </p>
                                        <div class="provider">
                                            
                                            <div class="content">
                                                <h4>Itol Gold Borja</h4>
                                                <span>   </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Item -->
                            </div>
                        </div>
                        <div class="col-lg-5 info">
                            <h4>Testimonials</h4>
                            <h2>Check what our satisfied Employees said</h2>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End testimonials Area -->
    </div>
    <!-- End Overflow Hidden Box -->